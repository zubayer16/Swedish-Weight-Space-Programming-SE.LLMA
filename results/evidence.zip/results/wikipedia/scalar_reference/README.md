# Scalar reference timing run

The first expanded run completed the base condition using the original per-chunk
scorer. It was stopped during the adapted condition to add throughput-only batching;
only completed base measurements are preserved here. At roughly four and a half
minutes per condition, it projected to almost two hours for all 24 conditions.

The expanded full run restarts all conditions with equal-length chunk batches of
eight. Each chunk keeps its own independent context: no padding, concatenation,
truncation, changed targets, changed tokenizer or changed weights. The original
scorer remains in src/evaluation.py, unchanged. New tests compare
the two implementations; the runner gates evaluation on agreement within 1e-5
NLL per document on real-checkpoint examples. Full-run base scores can also be
compared with the complete scalar base scores here.

This is a runtime optimization, not a mask or evaluation-hyperparameter search.
No model scores were used to select articles or alter the patching methods.
