# Result provenance

`full/` preserves the **original synthetic-text** main run, with eight test documents
per language. Its values have not been relabeled as Wikipedia measurements.
Redundant original smoke-test outputs were removed during cleanup.

`wikipedia/full/` is the expanded run on all 150 frozen Wikipedia excerpts per
language. `dataset_usage.json` records every document ID and corpus hash.
`resolved_config.json` and `run_identity.json` record fixed settings and source
fingerprints. `status.json` must say `complete` before results are considered final.
`wikipedia/quick/`, if run, uses only two frozen examples per language as a smoke test.

After a successful expanded full run, the following convenient primary artifacts
are copied to this directory:

- `experiment_results.csv`: one row per condition/seed/language/split. `test` is
  Wikipedia; `dev` is all legacy texts. The `gain_ci` fields use **base minus patch**;
  `delta_nll_vs_base` uses **patch minus base**.
- `method_summary.csv`: one row per method/fraction/language for Wikipedia only.
  NLL, paired change from base, English regression and Swedish gain-retention
  intervals; fixed-seed means, seed SD, document and token counts.
- `paired_comparisons.csv`: all pairs of methods/fractions, with 95% document-level
  bootstrap intervals. **Candidate minus reference**, negative favors candidate.
- `figures/`: primary evaluation plots and unchanged weight-distribution analysis.

Detailed `document_metrics.json` stores loss sums, scored target counts and chunks
for every document and condition. Match its document IDs to the frozen JSONL metadata
to inspect attribution. `paired_vs_base_per_seed.csv` retains individual-seed comparisons.

Random-method summaries average the fixed seeds' document loss sums before paired
bootstrap resampling. Identical document indices are used on both sides of each
comparison. Intervals quantify document variability conditional on those masks;
they do not include arbitrary future seeds or prove training-data independence.
They are pointwise, with no correction for multiple comparisons. Seeds and results
are all reported; no best seed or best method is selected for a new headline run.

After completion, 14 source modules were consolidated into six. The original run
identities were preserved. `source_refactor.json` maps the old hashes to the new
modules and records syntax-tree fingerprints for unchanged relocated definitions.
The audit validates these fingerprints for the core scoring and patch functions.
This refactor does not claim that the new file layout produced the historical run.
