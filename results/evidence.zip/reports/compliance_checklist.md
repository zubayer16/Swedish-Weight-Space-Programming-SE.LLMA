# Assignment compliance and experiment plan

The original three-page assignment PDF was read in full before implementation.
It remains local in references/ and is excluded from Git because permission to
redistribute it is unknown. The expanded user master prompt adds implementation
requirements beyond the original assignment.

| Assignment requirement | Implementation / evidence |
|---|---|
| Critically assess strongest evidence and limitations | research_note.md; distinguishes small direct-weight demonstrations, feedback-assisted edits, and this delta heuristic |
| One falsifiable Swedish-relevant claim | Layer-relative-norm allocation should retain more Swedish likelihood gain than random/DARE at equal counts |
| Small executable experiment | run_experiment.py, pinned 135M checkpoints, CPU fallback |
| Baseline and alternative controls | Base, full adaptation, random, DARE, magnitude, plus layer-random control |
| Separate development and evaluation examples | Fixed dev/test JSONL IDs; masks never depend on text losses |
| Target behavior and regression | Swedish and English token-weighted causal NLL |
| Quantitative results and configuration | results/{quick,full}/, revisions, seeds, per-document losses, bootstrap intervals |
| Recommendation and follow-up | research_note.md |
| Public repository source and instructions | README.md, requirements.txt, configs/, tests/; publication left to owner |
| Concise Markdown and separate PDF | reports/research_note.md and .pdf |
| AI disclosure | To be added later by the repository owner |
| Rights and resource constraints | AI-authored text; Apache-2.0 model cards; weights/cache excluded; no paid APIs |

## Prespecified design

Fractions 0.1/0.3; random seeds 17/29/43; group = transformer layer, input/output
embeddings, or final norm. Group score is ||delta_g||2 / max(||base_g||2,1e-12).
Allocate the exact global floor(f*N) budget proportionally to scores, cap at group
capacity and redistribute; integer allocation uses floor then stable remainders.
Choose largest absolute deltas within each group. This might protect strongly
adapted layers, but may underfund large layers or overweight small unstable norms.
No evaluation-driven hyperparameter search. Magnitude ties use canonical order.

Quick uses 2 dev and 2 test documents per language and one random seed. Full uses
3 dev and 8 test documents per language and three random seeds. Both fractions
and all methods are present in both modes. This is a small feasibility study.
Paired bootstrap resamples documents, not correlated tokens (2000 draws, seed 2026).
Only interpret gain retention when the full-model gain interval is entirely positive.
Patch L2 is exported to reveal edit-size differences, but does not by itself remove
the norm confound. No causal localization or inference speedup claim is warranted.

Optional Swe-BLiMP is deferred: the primary experiment and its small sample are
prioritized over acquiring and validating another benchmark within the time budget.
Sparse files are not serialized; no actual patch-storage saving is claimed.

## Completion audit

Both published checkpoints were downloaded and their exact revisions resolved and pinned.
Compatibility checks passed, including token-ID mappings; special-token configuration
differences are explicitly reported. Actual-model 0% and 100% reconstruction gates passed
before likelihood evaluation. Original unit suite: 26 passed; its redundant standalone log was removed during cleanup.
Quick completed 12 conditions; full completed 24 conditions (96 language/split metric rows),
on CPU. Full evaluation took about 7.9 minutes, excluding the earlier download/quick run.
All result losses are finite and exact retained counts were independently audited.
The final two-page PDF was rendered and visually inspected. Both layer and performance
figures were inspected; labels were adjusted for readability.

The hypothesis is not consistently supported: layer-aware selection loses to random at
10%, and to magnitude at 30%. No positive mechanistic claim is made. Optional Swe-BLiMP,
natural-corpus expansion, norm-matched controls, serialized sparse-file storage, and
remote GitHub publication remain outside this completed feasibility study's scope.
