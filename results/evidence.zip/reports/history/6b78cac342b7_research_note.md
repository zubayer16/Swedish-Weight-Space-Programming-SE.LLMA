# Where Does Swedish Adaptation Live?

**Md Zubayer Ahmed Fahim**

## 1. Question and motivation

Can selected weight changes preserve Swedish improvement without unnecessarily
worsening English prediction? I wanted to test whether checkpoint differences could
help SE.LLMA identify useful updates without another training run.

*Sparks of Weight-Space Programming* [1] motivated the question. Its independently
checked copying-head experiment provides stronger direct-weight evidence than edits
selected through behavioural feedback. I tested a narrower numerical rule, rather
than claiming to read Swedish competence directly from weights.

## 2. Experiment

My hypothesis was that layers with larger relative changes deserved more of a fixed
update budget. I compared SmolLM2-135M with a published Swedish checkpoint [2], retaining
10% or 30% of unique parameter positions. Controls were random selection, magnitude
selection, fixed-count DARE and random positions with identical layer budgets. Random
controls used seeds 17, 29 and 43; the base was restored before every intervention.

After an eight-document synthetic pilot per language, I evaluated the unchanged
methods on 150 frozen Wikipedia excerpts per language: 53,295 Swedish and 29,838
English scored tokens. Every method used identical texts, tokenization and independent
128-token chunks. Token-weighted negative log-likelihood (NLL; lower is better) measured
prediction; English checked regression. Paired document-bootstrap intervals used
2,000 draws. Model revisions, provenance and document-level measurements are archived.

## 3. Findings and follow-ups

The main Wikipedia comparison gave these NLL values; random is the fixed-seed mean:

| Method | Swedish NLL | English NLL |
|---|---:|---:|
| Base | 4.146 | 2.873 |
| Swedish checkpoint | 2.132 | 3.712 |
| Random 30% | 4.171 | 3.544 |
| Magnitude 30% | 3.966 | 4.313 |
| Layer-aware 30% | 4.332 | 4.289 |

Layer-aware selection lost to random at both budgets. At 30%, its Swedish disadvantage
was 0.161, with a paired 95% interval [0.104, 0.225]. Magnitude retained 8.9% of the full
Swedish gain; layer-aware retention was −9.2%, meaning worse than base. The pilot's
small positive layer-aware retention of 3.8% therefore did not carry over.

**Could balanced allocation help?** I wondered whether the rule assigned too little
capacity to useful updates elsewhere. Keeping the largest 30% within every layer
and the separate embedding/normalization groups preserved the same overall budget.
On 50 new documents per language, balanced Swedish NLL was 4.049 versus 4.371 for the
original rule: an improvement of 0.322 [0.268, 0.380]. However, it retained only 7.9%
of the full gain and English NLL remained poor at 4.412.

**Could a weaker dense update work better?** I next tested keeping all changes but
scaling their strength: base + α × checkpoint difference. Eight fixed values were
compared on legacy development texts, selecting the lowest equal-language mean NLL
before collecting another 50 documents per language. Selection chose α = 1.0. This
full endpoint achieved Swedish/English NLL of 2.131/3.698, versus 3.997/4.326 for balanced
30% and 4.148/2.871 for base. It did not confirm an intermediate-strength solution;
other α values were measured only on development data. Dense and sparse edits also
retain different numbers of positions.

## 4. Interpretation and recommendation

The original hypothesis was unsupported. Balanced allocation improved one comparison
but did not resolve the bilingual trade-off. DARE's large losses concern this
checkpoint difference and rescaling setup, not DARE generally [3]. Equal parameter
counts did not match update norms, and no English-regression tolerance was fixed.

One checkpoint pair, short Wikipedia excerpts and possible training-data overlap
limit generalization. NLL does not test reasoning or idiomatic Swedish. Structural
compatibility passed, but ancestry remains unresolved: card metadata names an
Instruct parent while the paper describes original-model continued pretraining [2, 4].
The difference cannot therefore be attributed solely to Swedish training.

I would retain this as a diagnostic study, not recommend the sparse rule for
deployment. I would first verify ancestry, then compare norm-matched edits with a
development-set English tolerance and confirmation on another Swedish domain.

## References and AI usage

[1] [Sparks of Weight-Space Programming](https://rikiyat.github.io/blog/weight-space-programming/).
[2] [Swedish checkpoint](https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish).
[3] [DARE](https://arxiv.org/abs/2311.03099).
[4] [Kunz: Idiomatic Language Acquisition](https://arxiv.org/abs/2602.03484).

Codex assisted with implementation, collection, testing, analysis and report drafting.
Legacy examples were AI-authored; Wikipedia excerpts were not generated or translated
by the pipeline. No independent external replication is claimed.
