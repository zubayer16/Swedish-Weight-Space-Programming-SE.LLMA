# Where Does Swedish Adaptation Live?

Expanded frozen Wikipedia evaluation - full mode - 19 November 2026

## 1. Research question and motivation

**Main research question:** Can weight-only layer allocation preserve more Swedish continued-pretraining gain than
random or DARE at identical 10% and 30% parameter budgets, without disproportionate English
regression?

I wanted to examine whether the changes introduced during Swedish adaptation contain
enough structural information to guide a useful sparse intervention. This matters for
SE.LLMA because it could help identify which adaptation updates are worth preserving.
The experiment retains the hypothesis and masks from the original study.
Lower Swedish NLL than random and DARE at both budgets would support the selection
claim; equal or worse Swedish scores challenge it. English regression is descriptive:
no numerical acceptability threshold was fixed, so a joint deployment claim is untested.

## 2. What does the existing evidence establish?
Sparks of Weight-Space Programming [1] provides its clearest direct-weight evidence in
small networks, including independently checked copying heads with embeddings removed.
However, weights alone did not identify sycophancy in its larger-model test; attention
probes were needed. The larger math-editing experiment used behavioral feedback and
addressed a looping failure, so it does not establish general weight-only understanding
or new ability. Small, structured tasks and limited replications constrain transfer.
This study tests a numerical delta-selection heuristic, not an LLM reading semantics
from weights or a reproduction of the article's strongest experiments.

## 3. How was the comparison designed?

The public Wikimedia Action API supplied 150 Swedish and 150 English community-written
articles, frozen at 2026-11-19T00:05:27.276004+00:00. Namespace-zero, nonredirect articles of at
least 5,000 source bytes were sampled using the API random generator. Marked automated
pages, disambiguations, list titles, insufficient prose, duplicate hashes/pages and
duplicate Wikidata topics across languages were excluded. Paragraphs in article order
were cleaned consistently, excluding tables, notices, citations and reference sections.
Each document is an explicit 100-200-word sentence-ended excerpt (first boundary after
120 words preferred). An initial lead-only collection pilot was revised before evaluation
because short introductions excluded substantial articles; its cached candidate sequence
was reused. The manifest records the final rules and all acceptance/rejection decisions.

JSONL files freeze exact text, article/revision IDs, timestamps, URLs, attribution,
CC BY-SA 4.0 terms, transformations and SHA-256 hashes. Rerunning preparation verifies
these bytes without resampling. API random selection itself is not seedable. Excerpts
contain no AI-generated or translated replacement text; Wikipedia's editing history
cannot guarantee exclusively human authorship. The 3 old dev plus 8 old test examples
per language are now legacy development data, with their files and original results preserved.

Base revision: 93efa2f097d58c2a74874c7e644dbc9b0cee75a2 (HuggingFaceTB/SmolLM2-135M).
Swedish revision: 3a80f1642cffaf656958647e213e49436415134d (jekunz/smollm-135m-cpt-fineweb-swedish).
Compatibility and 0%/100% reconstruction gates passed. Token-ID mappings match; differing
BOS/EOS/PAD settings are bypassed by the unchanged base tokenizer with no inserted specials.
These gates establish structural compatibility, not ancestry. The pinned Swedish
card metadata names SmolLM2-135M-Instruct, while its prose and associated paper [4]
describe continued pretraining of the original SmolLM2. This unresolved provenance
conflict prevents attributing the entire delta specifically to Swedish training.
The measured checkpoint interventions remain valid; checkpoints were not replaced.
All patches use float32 base-plus-delta, count tied weights once, and restore base between
conditions. Masks remain random, inverse-retention-scaled DARE [2,3], global magnitude,
relative-norm layer allocation with within-layer magnitude, and layer-random. Seeds are
17/29/43; deterministic methods run once. No new result influenced mask selection or tuning.
Here DARE uses a uniform fixed-count mask, shared with unscaled random at each seed,
and N/k scaling; the original method uses Bernoulli dropping. Equal counts therefore
isolate rescaling from mask choice but do not match update norms. This continued-
pretraining stress test differs from DARE's supervised-fine-tuning setting; its poor
scores do not refute DARE generally. No norm-matched control was run.

The unchanged scorer uses 128-token chunks sharing one boundary token, no document
concatenation, no padding or further truncation, and scores every frozen token except
each document's first. A throughput wrapper batches eight equal-length chunks with
independent contexts; unit tests and a real-checkpoint gate verify agreement with the
unchanged scalar scorer within 1e-5 NLL per document. 150 Swedish documents/53,295 targets and
150 English documents/29,838 targets were scored for every condition.
The run took 99.4 minutes on cpu. Whole-document paired bootstrap
uses 2,000 draws, seed 2026. Stochastic-method intervals resample mean document loss across
the three fixed seeds; seed SD is separate. Intervals are pointwise, with no multiplicity
correction. Gain retention is defined only when the full-adaptation gain interval is positive.

## 4. What did the experiment show?

NLL is token-weighted, in nats/token; lower is better. Random-method entries are fixed-seed means.

| Method | Retained | Swedish NLL | English NLL | SV gain | EN change |
|---|---:|---:|---:|---:|---:|
| base | 0% | 4.146 | 2.873 | 0.0% | +0.000 |
| adapted | 100% | 2.132 | 3.712 | 100.0% | +0.838 |
| random | 10% | 4.197 | 3.122 | -2.5% | +0.248 |
| dare | 10% | 48.857 | 48.787 | -2219.5% | +45.913 |
| magnitude | 10% | 4.455 | 3.742 | -15.4% | +0.869 |
| layer | 10% | 4.427 | 3.588 | -13.9% | +0.714 |
| layer_random | 10% | 4.301 | 3.137 | -7.7% | +0.263 |
| random | 30% | 4.171 | 3.544 | -1.2% | +0.670 |
| dare | 30% | 22.196 | 22.932 | -896.0% | +20.059 |
| magnitude | 30% | 3.966 | 4.313 | 8.9% | +1.440 |
| layer | 30% | 4.332 | 4.289 | -9.2% | +1.416 |
| layer_random | 30% | 4.399 | 3.444 | -12.6% | +0.571 |

Full Swedish adaptation changes Swedish NLL by -2.014
(95% paired interval [-2.060, -1.968]) and English
by +0.838 ([+0.800, +0.881]).
Negative differences below favor layer-aware selection; positive values favor the control.

| Language | Layer minus control | Retained | NLL difference | 95% interval |
|---|---|---:|---:|---:|
| sv | random | 10% | +0.230 | [+0.212, +0.249] |
| sv | magnitude | 10% | -0.028 | [-0.038, -0.019] |
| sv | random | 30% | +0.161 | [+0.104, +0.225] |
| sv | magnitude | 30% | +0.366 | [+0.337, +0.397] |
| en | random | 10% | +0.466 | [+0.447, +0.485] |
| en | magnitude | 10% | -0.155 | [-0.170, -0.140] |
| en | random | 30% | +0.745 | [+0.672, +0.835] |
| en | magnitude | 30% | -0.024 | [-0.055, +0.005] |

Full per-condition losses and token counts are in document_metrics.json; method_summary.csv
contains NLL, regression and gain-retention intervals; paired_comparisons.csv includes
all method pairs, including DARE and layer-random. Figures are in results/figures/.

## 5. How do these findings compare with the original study?

The original eight AI-authored test documents per language gave Swedish base/full NLL 4.148/1.725. At 30%, magnitude/layer retained 14.8%/3.8% of that gain. Wikipedia instead gives 8.9%/-9.2%. These are distinct domains, not a paired cross-dataset comparison.
Original artifacts remain under results/full/ and reports/legacy/; expanded outputs are
under results/wikipedia/full/, with primary CSVs copied to results/. The larger natural
corpus strengthens coverage over the synthetic pilot but does not make Wikipedia representative
of all Swedish usage. The hypothesis is not consistently supported: layer-aware selection does not beat random with a negative paired interval at both budgets.

A separately planned balanced-allocation confirmation used 50 new articles per language. At 30%, Swedish NLL fell from 4.371 to 4.049, but retained only 7.9% of the full gain. This narrows the allocation problem without solving English regression (reports/follow_up.md). A second development-selected dense comparison chose alpha 1, the full-adaptation endpoint, before collecting another 50 articles per language. It does not confirm an intermediate-strength solution (reports/dense_follow_up.md).

## 6. What can be concluded, and what should come next?

The test set is held out from this experiment's mask design, not proven independent of
model training. Wikipedia or its mirrors may occur in base pretraining and Swedish
FineWeb-2; a newer revision does not make its text new. No decontamination was performed.
Article-size/prose filters, opening excerpts and bot-marker filtering introduce selection
bias. Short context, one small checkpoint pair, and document-level uncertainty limit
generalization. English NLL checks one regression only. Equal parameter counts do not
match patch norms, and no numerical English acceptability threshold was prespecified.
No sparse inference speedup, new reasoning ability, or Swedish cultural competence follows.

SE.LLMA should retain this as a negative pilot, not adopt the sparse heuristic as a
reliable transfer method. The most informative next experiment is a fixed norm-matched control
on a separate natural Swedish domain and idiomatic minimal pairs, then selective rollback
after instruction tuning. The optional Literature Bank check was deferred to finish the
primary 300-document evaluation; no literary-domain results are claimed.

## Research references

[1] https://rikiyat.github.io/blog/weight-space-programming/

[2] https://arxiv.org/abs/2311.03099 ; [3] https://arxiv.org/abs/2410.09344

Model lineage: https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish

[4] https://arxiv.org/html/2602.03484v1#S4.SS1

API: https://www.mediawiki.org/wiki/API:Random ; https://www.mediawiki.org/wiki/API:Etiquette

Text license: https://creativecommons.org/licenses/by-sa/4.0/ . Individual contributors
are attributed through article and history URLs in each JSONL record (see data/LICENSE.md).
Codex implemented collection, tests, analysis and reporting and executed the runs. It did
not author the Wikipedia evaluation text. No independent review is asserted.
