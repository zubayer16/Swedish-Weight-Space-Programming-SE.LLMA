# Where Does Swedish Adaptation Live?

Research note - full evaluation, 19 November 2026

## Question and falsifiable hypothesis
Can weight-only layer allocation preserve Swedish adaptation better than uniform random
and DARE at identical 10% and 30% parameter budgets, without disproportionate English
regression? Better Swedish token likelihood with acceptable English loss would support
this hypothesis; equal or worse results challenge it. Sparse transfer could support
SE.LLMA's investigation of language adaptation, but does not reduce dense inference cost.

## Critical assessment
The strongest direct-weight evidence in Sparks of Weight-Space Programming [1] is the
middle-layer experiment: input/output embeddings are removed and predicted copying heads
are checked independently. It is small and structured. Its language-model editing results
use behavioral feedback, which makes them evidence for feedback-assisted intervention,
not weight-only understanding. Failure to identify sycophancy from weights alone and the
failure to improve a nonlooping model constrain general claims. Removing a failure mode
can reveal existing ability without creating a new one. Our experiment examines training
deltas using a numerical heuristic; it tests neither direct semantic reading of weights
nor repeated behavioral optimization. DARE [2] randomly drops and rescales deltas; DAREx
[3] warns of failures under large updates/rescaling. Continued pretraining is a useful
stress test beyond the original supervised fine-tuning setting.

## Setup and methods
Base: HuggingFaceTB/SmolLM2-135M, revision 93efa2f097d58c2a74874c7e644dbc9b0cee75a2.
Adapted: jekunz/smollm-135m-cpt-fineweb-swedish, revision 3a80f1642cffaf656958647e213e49436415134d.
The model card describes Swedish FineWeb-2 continued pretraining [4]. Structural,
token-ID mapping, finite-value, and tied-storage checks passed. Config BOS/EOS/PAD
IDs differ: (0,0,None) versus (1,2,2). We use the base tokenizer without inserted
special tokens, avoiding dependence on those settings. Deltas and reconstruction
are float32; tied embeddings are counted once.

Layer score = L2(delta)/L2(base). Capped proportional allocation with deterministic
integer rounding gives an exact global floor(f*N) count; within each group, largest
absolute deltas survive. Zero-score groups receive residual capacity when necessary.
This could protect relatively adapted layers, but relative norms may overvalue small
groups. Controls: random without scaling; DARE with N/k scaling; global magnitude;
and identical layer counts with random positions. Ties use parameter/position order.
Each evaluation restores base plus exactly one patch. Actual retained/modified counts
and patch norms are in the CSV; matching counts does not match intervention norms.

The fixed AI-authored corpus has 3 development and 8 test documents per language.
Full mode scores 8 test documents / 954 Swedish target tokens
and 8 documents / 459 English targets. Full mode uses seeds
17/29/43; quick uses 17. No mask is tuned against either split. Evaluation uses dropout-free
causal NLL, no padding, 128-token chunks sharing one boundary token, no silent truncation,
and token-weighted aggregation. Every document's first token is unscored. CPU execution
took 7.9 minutes. Unit and actual-checkpoint 0%/100% reconstruction gates passed.

## Actual observations
Random-method rows below are seed means; deterministic rows are single masks.

| Method | Retained | Swedish NLL | English NLL | Swedish gain retained |
|---|---:|---:|---:|---:|
| base | 0% | 4.148 | 3.607 | 0.0% |
| adapted | 100% | 1.725 | 4.332 | 100.0% |
| random | 10% | 4.221 | 3.869 | -3.0% |
| dare | 10% | 49.039 | 49.475 | -1852.2% |
| magnitude | 10% | 4.570 | 4.389 | -17.4% |
| layer | 10% | 4.516 | 4.227 | -15.2% |
| layer_random | 10% | 4.361 | 3.865 | -8.8% |
| random | 30% | 4.161 | 4.325 | -0.5% |
| dare | 30% | 22.131 | 24.054 | -742.0% |
| magnitude | 30% | 3.790 | 4.770 | 14.8% |
| layer | 30% | 4.056 | 4.791 | 3.8% |
| layer_random | 30% | 4.564 | 4.130 | -17.2% |

Full adaptation changes Swedish NLL by -2.424 and English NLL by
+0.725 relative to base. The paired document bootstrap interval for
base-minus-full Swedish NLL is [2.338, 2.523]
(2000 resamples, seed 2026). Gain retention is reported only if this interval is
entirely positive. At 10%, layer-aware Swedish NLL is 4.516 versus magnitude 4.570. At 30%, layer-aware Swedish NLL is 4.056 versus magnitude 3.790.
At 10%, layer-aware minus random Swedish NLL is +0.295; layer-aware minus DARE is -44.523. At 30%, layer-aware minus random Swedish NLL is -0.105; layer-aware minus DARE is -18.075. Negative differences favor layer-aware selection.
See results/full/seed_summary.csv for seed dispersion and document_metrics.json
for paired observations. Intervals capture this tiny document sample, not population validity.

## Interpretation, limitations, and recommendation
The layer-aware heuristic fails to outperform mean random Swedish NLL consistently across both budgets; the broad hypothesis is not supported.

The table tests the prespecified heuristic against controls; a sparse patch's success
would show useful information in training differences, not causal localization of Swedish.
Global magnitude is a necessary conventional comparator. Layer-random separates layer
allocation from position choice. Exported patch norms expose an unresolved edit-size
confound; a norm-matched sweep is needed before attributing differences to structure.
There is no prespecified numerical tolerance for acceptable English regression, so the
joint hypothesis cannot be declared confirmed by Swedish loss alone.

This is a feasibility study with one small model, a tiny AI-authored sample, short
context and limited linguistic coverage. Text was not sampled from a benchmark; possible
training overlap is not excluded. English NLL checks one regression only, and neither
NLL nor a norm distribution establishes reasoning, idiomatic or cultural competence.
Swe-BLiMP and serialized sparse-file storage were deferred. We recommend further controlled
evaluation only as a low-cost diagnostic, not adoption of this heuristic as established.
The most informative follow-up is a preregistered, norm-matched comparison on a licensed
natural Swedish corpus plus idiom minimal pairs, followed by selective rollback after
instruction tuning to test whether lost idiomatic preferences can be recovered.

## Sources and disclosure
[1] Takehi et al., Sparks of Weight-Space Programming (2026): https://rikiyat.github.io/blog/weight-space-programming/

[2] Yu et al., Language Models are Super Mario: https://arxiv.org/abs/2311.03099

[3] Deng et al., DARE the Extreme: https://arxiv.org/abs/2410.09344

[4] Checkpoint card: https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish

[5] SE.LLMA objectives: https://wasp-sweden.org/research/projects/sellma/

Codex designed, coded, executed, analyzed, and drafted this work; see AI_USAGE.md.
No independent human review is asserted. Original assignment PDF reread before report generation.
