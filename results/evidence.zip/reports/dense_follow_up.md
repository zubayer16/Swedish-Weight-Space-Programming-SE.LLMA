# Can We Reduce Adaptation Strength Instead of Selecting Weights?

Prespecified follow-up to the SE.LLMA sparse-patch experiments.

## 1. What was tested?

The earlier balanced allocation improved Swedish retention but still damaged English.
This experiment tests base + alpha times (adapted - base): a smaller amount of the
entire update. Alpha controls adaptation strength. Every unique parameter position
is retained in a dense update; alpha is not a sparsity fraction. A dense result
therefore does not establish compression or superiority at equal storage cost.

The checkpoint revisions, float32 arithmetic, tokenizer, 128-token chunks,
independent document contexts and scoring rules are unchanged. The plan is saved in
reports/dense_follow_up_plan.md. Both previous studies and their reports are preserved.
Lineage remains uncertain: the pinned Swedish card metadata names the Instruct
parent, while its prose and associated paper describe original-model continued
pretraining. This is a checkpoint-delta experiment, not a verified isolation of
Swedish-only training effects (see reports/assignment_audit.md).

## 2. How was alpha selected?

All 11 legacy examples per language were used for development, including the eight
former synthetic test examples. These AI-authored, already observed texts are not
held-out evidence. The fixed eight-value alpha grid was scored in full. Selection
minimizes the arithmetic mean of the two language NLLs; exact ties favor smaller alpha.
Equal language weighting is an explicit preference, not a universal utility measure.

| Alpha | Swedish NLL | English NLL | Mean | Selected |
|---:|---:|---:|---:|---|
| 0 | 4.132 | 3.597 | 3.864 |  |
| 0.05 | 4.011 | 3.600 | 3.806 |  |
| 0.1 | 3.919 | 3.618 | 3.769 |  |
| 0.2 | 3.754 | 3.680 | 3.717 |  |
| 0.3 | 3.541 | 3.762 | 3.651 |  |
| 0.5 | 2.870 | 3.947 | 3.408 |  |
| 0.75 | 1.996 | 4.159 | 3.078 |  |
| 1 | 1.716 | 4.356 | 3.036 | yes |

Selected alpha: 1. Selection and development hashes were saved before
collecting confirmation data. No confirmation score changed this choice.
The selected endpoint is full adaptation, not evidence that a weaker alpha works
on held-out texts. Intermediate alphas were measured only on development data.

## 3. What happened on fresh documents?

Fifty Wikipedia excerpts per language were collected after selection, excluding
both previous corpora by language/page ID, Wikidata topic and content hash.
The same cleaning, attribution, revision and CC BY-SA licensing rules apply.
All conditions score identical targets (sv: 50 documents, 17,962 tokens; en: 50 documents, 10,527 tokens). Duplicate endpoint measurements
are reused if the selected alpha is 0 or 1. NLL is in nats/token; lower is better.
Swedish gain retention is defined only when the full-adaptation gain has a positive
paired interval. English change is relative to base.

| Method | Swedish NLL | English NLL | SV gain | EN change |
|---|---:|---:|---:|---:|
| base | 4.148 | 2.871 | 0.0% | +0.000 |
| adapted | 2.131 | 3.698 | 100.0% | +0.828 |
| dense (alpha 1) | 2.131 | 3.698 | 100.0% | +0.828 |
| balanced 30% | 3.997 | 4.326 | 7.5% | +1.455 |
| magnitude 30% | 3.931 | 4.262 | 10.7% | +1.391 |

The primary selected-dense-minus-balanced-30% difference in equal-language mean NLL
is -1.247, with a 95% paired document-bootstrap
interval [-1.291, -1.205]. This supports a lower bilingual mean for the selected dense adaptation.
A lower mean does not imply that both languages improve.

| Language | Dense minus control | Control retained | NLL difference | 95% interval |
|---|---|---:|---:|---:|
| sv | base | 0% | -2.017 | [-2.080, -1.955] |
| sv | adapted | 100% | +0.000 | [+0.000, +0.000] |
| sv | balanced | 30% | -1.866 | [-1.926, -1.806] |
| sv | magnitude | 30% | -1.800 | [-1.889, -1.722] |
| en | base | 0% | +0.828 | [+0.778, +0.878] |
| en | adapted | 100% | +0.000 | [+0.000, +0.000] |
| en | balanced | 30% | -0.627 | [-0.690, -0.570] |
| en | magnitude | 30% | -0.563 | [-0.722, -0.446] |

The primary bootstrap independently resamples whole paired documents within each
language and averages the language differences. Language intervals also use whole
paired documents. There are 2,000 draws, seed 2026. Intervals are pointwise with
no multiple-comparison correction. Negative differences favor selected dense.
Global magnitude 30% is a secondary control. All measured conditions are retained.

## 4. What are the limits?

This experiment checks adaptation strength against sparse selection for one small
checkpoint pair. The development texts are synthetic and may choose a strength
that transfers poorly to Wikipedia. The objective can conceal a language trade-off;
the separate language results must determine whether it suits a proposed use.
Fresh page/topic/hash exclusions do not establish training-data independence or
exclude similar passages. Wikipedia confirmation does not test domain generalization.
Fifty documents per language and short excerpts limit precision.

The prior artifacts passed byte-hash preservation checks, and all conditions passed
the document-ID and token-count audit. Zero/full reconstruction, compatibility,
scalar/batched agreement and the test suite passed before confirmation.
The recorded 6.1 minutes on cpu covers
the final resumed attempt only. An earlier attempt stopped during collection with
a Windows file-replacement error; its development sweep and partial corpus were
reused. Total compute time across attempts was not recorded and is not claimed.
This is a fixed confirmation experiment; its texts should not become an undisclosed
tuning set. The original sparse hypothesis remains a separate negative finding.

## Research references

Exact design and source hashes: results/dense_follow_up/design.json.
Frozen selection: results/dense_follow_up/selection.json.
Document losses, tokens, bootstrap tables and plots: results/dense_follow_up/.
Provenance and licenses: data/dense_follow_up/dataset_manifest.json and data/LICENSE.md.
Earlier reports: reports/research_note.md and reports/follow_up.md.

Wikimedia text license: https://creativecommons.org/licenses/by-sa/4.0/
