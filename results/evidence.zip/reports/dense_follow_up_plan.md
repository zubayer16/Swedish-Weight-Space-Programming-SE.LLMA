# Scaled dense adaptation: fixed experimental plan

This follow-up asks whether reducing the strength of the entire adaptation gives a
better Swedish-English balance than retaining 30% of updates. It was motivated by
the observed sparse-patch regressions. It does not revise either earlier study.

The checkpoints and revisions, float32 arithmetic, tokenizer, independent document
contexts, 128-token scoring, batching and deterministic execution remain unchanged.
Dense weights are base + alpha * (adapted - base), with tied weights counted once.
Alpha is adaptation strength, not retained parameter fraction. This is not a
compression method and does not have the same parameter budget as a sparse patch.

Before collecting confirmation data, evaluate alpha in
[0, 0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1] on all 11 legacy development examples in each
language (including the eight former synthetic test examples). These AI-authored,
already observed texts are development only. Select the alpha minimizing the
arithmetic mean of Swedish and English token-weighted NLL; exact ties favor the
smaller alpha. Equal language weighting is an explicit operational preference,
not a universally correct utility function. No confirmation result changes alpha.
The selection, all development observations and hashes are saved before collection.

Collect 50 fresh Wikipedia documents per language using the existing prose and
licensing rules. Exclude both previously observed corpora by language/page ID,
Wikidata topic and content hash. Fifty per language is fixed to bound CPU cost.
Freeze these documents and score base, full adaptation, the selected dense alpha,
balanced 30% and global magnitude 30% on identical targets. Reuse exact duplicate
endpoint measurements if alpha is 0 or 1. Do not choose a different alpha afterward.

The primary comparison is selected dense minus balanced 30% on the equal-language
mean NLL objective. Resample whole paired documents independently within each
language, then average the two differences: 2,000 draws, seed 2026, pointwise 95%
percentile interval. Report both language differences and intervals separately;
a lower bilingual mean does not prove both languages improved. Global magnitude
30% is a secondary control. Retain negative findings and all scored conditions.

Report document-level losses, token counts, selection artifacts, language NLLs,
Swedish gain retention where defined, English regression, and development and
confirmation plots in a separate Markdown/PDF report. Audit original results for
unchanged bytes. Corpus disjointness does not establish training independence;
synthetic development texts, Wikipedia confirmation, one checkpoint pair and this
chosen utility function limit generalization. No additional tuning follows here.
