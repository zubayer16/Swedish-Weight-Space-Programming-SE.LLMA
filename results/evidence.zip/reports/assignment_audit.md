# SE.LLMA assignment audit

Packaging note: detailed paths cited below now live inside `results/evidence.zip`
and `data/datasets.zip`. Run `python run_project.py --unpack-only` to inspect their
original paths under `.cache/work/`. Packing preserves the original bytes and adds
SHA-256 manifests. The current packaging suite has 46 passing tests; the 44-test
count below describes the earlier scientific review. No scientific measurement changed.

Reviewed 19 November 2026 against all three pages of the original local assignment,
`references/Candidate assignment_ Weight space programming for SE (1).pdf`, and the
subsequent dataset, follow-up and reproducibility requests. The PDF was reread in full.
Document suggestions are distinguished below from mandatory submission requirements.
This is a Codex-assisted internal review, not an independent external replication.

**Verdict:** a working, technically consistent negative checkpoint-intervention study
is complete locally. The original sparse-selection hypothesis is unsupported. The
project is **not a completed public submission**, and a provenance conflict prevents
interpreting its delta as a verified isolation of Swedish-only continued pretraining.
No checkpoint, observed loss, mask strategy, fraction or seed was substituted.
No commit or push was made.

## 1. Important findings and corrections

**High: checkpoint ancestry is unresolved.** The configured baseline is
`HuggingFaceTB/SmolLM2-135M`. At the pinned Swedish revision, model-card YAML instead
declares `HuggingFaceTB/SmolLM2-135M-Instruct` as its parent. The card prose and the
associated paper's section 4.1 describe original-model continued pretraining. This
is conflicting evidence, not proof that the wrong parent was actually used.
Architecture, parameter shapes, vocabulary IDs and tied storage match, but these
checks cannot establish training ancestry. All current reports and README now state
that limitation. The numerical interventions are valid for these two checkpoints;
claims that their entire difference was caused by Swedish training are unsupported.
Resolving this requires authoritative training provenance, not guessing a new base.
The archived legacy report remains an unchanged historical record; this caveat also
applies to its interpretation.

Evidence: [pinned Swedish model card](https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish/blob/3a80f1642cffaf656958647e213e49436415134d/README.md),
[associated paper, section 4.1](https://arxiv.org/html/2602.03484v1#S4.SS1),
and `results/evaluator_audit/external_sources.json`, which records card hashes and metadata.

Follow-up inspection of released training code and static training arguments is
documented in [checkpoint_ancestry.md](checkpoint_ancestry.md), with immutable source
links and `results/evaluator_audit/checkpoint_ancestry.json`. The original repository
releases only a different model's instruction-tuning script; target training arguments
omit the initializing model/revision. Related Instruct training code is not tied to
this checkpoint. The ancestry status therefore remains unresolved rather than guessed.

**High: submission is incomplete.** A read-only public GitHub API check returned only
`README.md` at the repository root. Locally, `git ls-files` also lists only README;
implementation, datasets, reports and results remain untracked. A public URL is not
evidence that this implementation has been submitted. Publication remains outstanding
under the user's explicit instruction not to push anything.

**Medium: DARE needs a qualified interpretation.** The implementation uses exactly
floor(fraction times N) positions without replacement and scales by N/k, rather than
independent Bernoulli dropping. It shares its mask with unscaled random at the same
seed, making rescaling the controlled difference. The original paper targets SFT
deltas; this is a continued-pretraining/checkpoint-difference stress test. Counts are
matched, norms are not. Large DARE losses are real recorded outcomes, not evidence
that DARE generally fails. The reports now explain this. A norm-matched control and
rescaling sweep were not run and must not be implied.
See the [DARE paper](https://arxiv.org/abs/2311.03099).

**Medium: the dense experiment selected an endpoint.** The fixed development rule
selected alpha 1.0. On fresh texts, the selected dense condition therefore reuses
the full-adaptation observations exactly. Intermediate alphas have development
measurements only. The reports now explicitly reject interpreting this as held-out
confirmation of weaker adaptation. Its recorded 6.1-minute runtime covers the final
resumed attempt, not all interrupted work; this is corrected in the report.

**Technical fixes:** collection now retries transient Windows permission failures
without replacing the previous good state with a truncated file. Frozen validation
now checks collection-audit hashes, document-ID uniqueness, license terms and recorded
cleaning rules, in addition to text/file hashes. New tests exercise file locks,
provenance tampering, fixed-count DARE scaling and cross-tensor magnitude selection.
Nested dataset JSON/JSONL files are protected from Git line-ending conversion.
Previously ranged direct dependencies are pinned to observed installed versions.
The one-command report refresh regenerates all completed reports without inference.
Historical design files and quantitative artifacts were not rewritten.

## 2. Original assignment: requirement-by-requirement

Complete means evidence exists locally and was checked; it does not imply that the
hypothesis succeeded or that the files are published. Partial means a specific
limitation remains. Not completed means the requested deliverable/action is absent.

| Assignment requirement | Status | Evidence and remaining limit |
|---|---|---|
| Read and critically examine the specified research | Complete | Current note distinguishes small direct-weight evidence, larger feedback-assisted edits and negative controls; original article was revisited during this audit. |
| Identify strongest evidence, limitations and justified conclusions | Complete | Embedding-free copying-head identification is stronger direct evidence; sycophancy needed probes and the larger math edits used feedback. General semantic weight understanding is not established. |
| Distinguish reasoning about weights from repeated behavioral optimization | Complete | Original masks depend on weights only; dense alpha selection explicitly uses development feedback. Neither is claimed to reproduce LLM semantic weight reading. |
| One narrow, relevant and testable hypothesis | Partial | Relative-norm allocation versus random/DARE at fixed budgets is testable. Its interpretation as specifically Swedish-induced structure is limited by unresolved ancestry. |
| Explain importance and supporting/challenging outcomes | Complete | Research note explains SE.LLMA relevance and Swedish superiority/equal-or-worse criteria. No post-hoc English threshold is invented. |
| Design and actually run a small meaningful experiment | Complete | Original 24 conditions, expanded 24 conditions and two separate confirmation experiments have completed output files. No large model training was required. |
| Reasonable alternatives and unchanged baseline | Complete | Base, full adapted checkpoint, unscaled random, DARE variant, global magnitude and layer-random controls; balanced and selected dense follow-ups. |
| Keep development/selection examples separate from evaluation | Complete | Original methods were fixed for the 150-per-language set. Observed results motivated later questions, each tested on a separate 50-per-language corpus. Dense selection uses only the 11 legacy examples per language, saved before collection. |
| Measure target behavior and at least one regression | Complete | Swedish token NLL and English token NLL on identical condition-specific targets; English is one regression proxy, not all capabilities. |
| Include examples, quantitative outcomes and limitations | Complete | Frozen JSONL includes actual text and provenance; document metrics and audit example rows expose individual outcomes; reports retain negative findings. |
| Recommend whether SE.LLMA should pursue the approach and a next experiment | Complete | Retain as a negative pilot, do not adopt the heuristic; resolve provenance and use fixed norm-matched controls on a separate natural/idiomatic domain. |
| Implementation and straightforward main reproduction | Complete locally | `python run_project.py`; tests/config/data/model revisions included. Clean-environment installation was not independently performed. |
| Outcomes, configurations, model revisions and random seeds | Complete locally | Main/follow-up CSV/JSON, pinned commit revisions, fractions 10%/30%, seeds 17/29/43 and bootstrap seed 2026. |
| Concise Markdown research note, approximately 1–2 pages | Partial | `research_note.md` covers all requested content, but is about 1,489 whitespace words including tables/references; tightening toward the suggested length remains an editorial improvement. |
| PDF based on the note, permitted to exceed two pages | Complete | All three current PDFs were regenerated, extracted and visually reviewed; each is three pages. Main tables and numerical values match their Markdown and CSV. |
| Short AI-tools/contribution description | Complete at the minimum | Current main note names Codex contributions to implementation, collection, tests, analysis, reporting and execution, and distinguishes legacy synthetic text. A separate `AI_USAGE.md` is intentionally absent at the user's request; their fuller personal disclosure remains to be added. |
| Use data/weights that may be used and shared | Complete for included artifacts | Both pinned model cards declare Apache-2.0; weights are downloaded separately and ignored. Wikipedia-derived text carries CC BY-SA 4.0 attribution/revision/history/change information. Assignment PDF is not tracked. No legal assurance about every historical contributor is claimed. |
| Public GitHub repository containing the implementation, results and note | Not completed | Public repository and local tracked tree currently contain README only. No publication was attempted. |

The suggested controls involving prompting, steering or new fine-tuning are examples,
not separate mandatory experiments. The four-hour effort is a scoping target, not a
required success criterion; retrospective total work time cannot be verified.

## 3. Expanded evaluation and follow-up requests

| Requested requirement | Status | Evidence and remaining limit |
|---|---|---|
| Public Wikimedia collection, 150 Swedish and 150 English documents | Complete | Main frozen corpus has exactly 150 per language; regular-prose filters and explicit rejection audits are recorded. |
| Consistent cleaning; no AI replacement or translation | Complete | Same cleaning code/rules for both languages, 100–200-word frozen excerpts; no text generation or translation stage. |
| Exclusively human-written source prose | Partial | Community Wikipedia provenance and marked-bot/AI exclusions are documented. Unmarked automation or AI edits cannot be ruled out. |
| Redirect/disambiguation/empty/duplicate/insufficient-prose exclusion | Complete within documented rules | Namespace/redirect/disambiguation, word budget, article IDs, content hashes and Wikidata-topic checks. Similar but nonidentical passages are not decontaminated. |
| Text, language, URL, article/revision IDs, timestamp, license and hash per document | Complete | All 500 frozen documents across the three corpora pass provenance and integrity checks. |
| Identifiable User-Agent, rate limiting, retries and explicit incomplete collection | Complete | Serial requests at least one second apart, maxlag/Retry-After handling and failure state. The actual Windows interruption is retained in the dense run log; bounded file-lock retries were added. |
| Freeze exact document sets and preserve legacy examples | Complete | Three manifests; original sample bytes unchanged. Legacy test fields are historical, not fresh confirmation labels. |
| Keep evaluation out of tuning and neuron/mask selection | Complete within observable implementation | Original masks use weights only; balanced design was fixed before new collection; dense alpha was frozen on legacy data before its new collection. Private human decisions before recorded plans cannot be independently proved. |
| All seven original methods at 10%/30% and fixed seeds | Complete | Main 24-condition schedule includes base/full and every requested sparse method/control. Deterministic methods run once; stochastic controls use all three seeds. |
| Identical tokenization, truncation, contexts and token-weighted NLL | Complete | Base tokenizer, no inserted specials/padding, every target except document first token, independent 128-token chunks. Real token counts and scalar/batch agreement verified. |
| Document loss sums and token counts plus aggregates | Complete | Stored per-document records reconcile with every checked CSV and summary. No cross-document concatenation. |
| Paired bootstrap intervals, retention/regression and document/token counts | Complete | All four expanded/follow-up stage summaries and pairwise files recomputed; ratios limited to positive full-gain denominators. Fixed-mask, pointwise uncertainty is explicitly qualified. |
| Updated tables, figures, README, Markdown and PDFs | Complete | Main and separate follow-up reports regenerated; corresponding figures exist. Archived legacy results remain separate. |
| Discuss changed conclusions and possible training-data overlap | Complete | Original negative finding retained; balanced only partially improves Swedish; dense selects full endpoint. Wikipedia/FineWeb overlap and ancestry uncertainty are explicit. |
| Optional Swedish literary-domain evaluation | Not completed; optional | No Literature Bank or other domain-generalization scores exist or are claimed. |
| Requested `src/prepare_datasets.py` filename | Complete functionally; superseded layout | Collection is `src/datasets.py` and `python -m src.datasets`, following the later six-module consolidation request. There is no duplicate compatibility script. |
| Full experiment, tests and honest compute reporting | Complete for recorded studies | No reduced subset was silently used in the main 300-document evaluation. Follow-up size 50/language was fixed in advance. Interrupted dense total compute is unknown, not inferred from the final attempt. |
| One script for workflow and report generation | Complete for documented modes | `run_project.py` runs main workflow; `--follow-up` and `--dense-follow-up` are explicit experiments; `--report-only` refreshes every completed report. `--audit-project` checks all existing evidence. |

## 4. What was executed and verified

- **44 tests passed**, with two nonfatal environment warnings (unused SciPy versus
  installed NumPy, and a pytz deprecation). New file-lock, provenance and mask-control
  tests pass. A fresh isolated dependency installation was not tested.
- Original main audit passed: 24 conditions, 96 rows, 150 Swedish documents/53,295
  target tokens and 150 English documents/29,838 targets. All 300 stored scalar-base
  document scores agree with batching within 4.77e-7 NLL/token, below 1e-5 tolerance.
- Rebuilt **24 real-checkpoint masks**: 22 original non-endpoint masks across the
  specified seeds/budgets, plus balanced 10% and 30%. Counts, recorded norms/scales,
  unscaled selected deltas, DARE/random shared masks and balanced budgets match.
  Re-tokenization verified targets/chunk counts for every one of the 500 frozen texts.
- Recomputed every summary, per-seed base comparison and pairwise interval for main
  Wikipedia (24 conditions), exploratory diagnostic (26, including 24 reused main
  conditions), balanced confirmation (14) and dense confirmation (5, including one
  explicitly reused endpoint). These are not 69 independent model runs.
- Checked original synthetic study document sums, CSV values and original 3/8 split
  IDs separately. Confirmed all prior inference artifacts against recorded hashes.
- Recomputed the dense alpha choice and primary independently stratified bilingual
  bootstrap interval. Selection precedes collection; no endpoint measurement is
  presented as an independent model outcome.
- Regenerated and rendered the three current PDFs. Tables, gains, regressions and
  three-decimal reported values reconcile with machine files; lineage caveats are
  present. All nine pages were visually checked for clipping and table layout.
- Checked public model-card licenses/metadata and read the public repository listing.
  No remote mutation occurred. No full likelihood experiment was repeated during
  this audit; its recorded observations were inspected and independently recomputed.

Commands: `python run_project.py --report-only`,
`python run_project.py --audit-project`, and
`python -m src.run_experiment --scientific-audit --check-weights`
(with local `.deps` and cached Hugging Face settings for the direct module command).

Evidence: `results/evaluator_audit/verification.json`, `weight_verification.json`,
`unit_checks.txt`, `external_sources.json`, `document_examples.csv`, and execution
logs. Weight verification was performed before the final report-only corrections;
its report hashes are historical. The separate final verification records refreshed
report hashes. The first two examples per language/corpus are exported in fixed
document order, not selected for favorable outcomes.

## 5. Interpretation and unresolved work

No evidence found of incorrect target shifting, document concatenation, double-counted
tied weights, cumulative patch application, inverted paired differences, wrong DARE
rescaling, seed cherry-picking, or changing the original masks using Wikipedia scores.
Passing technical checks does not establish a good intervention or causal localization.

The main hypothesis failed its Swedish comparison against random; balancing recovered
some Swedish gain while English still regressed. On the latest corpus, selected alpha
1 is full adaptation: Swedish/English NLL 2.131/3.698 versus balanced 3.997/4.326.
This favors full adaptation over that sparse control in both languages, while English
still worsens relative to base (2.871). It is not evidence of a new intermediate-alpha
solution, general language quality, sparse inference speedup or training independence.

Before a stronger causal follow-up, resolve the parent checkpoint discrepancy. Then
fix a natural-development objective/English tolerance, include norm-matched controls
and use a genuinely separate domain for confirmation. No such additional evaluations
were invented here. For submission, shorten the main note if desired, complete the
user's personal AI disclosure, and publish the complete artifact set only when the
user authorizes it.
