# Prespecified follow-up: balanced per-layer magnitude selection

The original relative-norm allocation lost to random on the observed Wikipedia
evaluation. This follow-up asks whether allocating the same retention rate to
every transformer block improves transfer. Shared embeddings and final norm are
separate groups, exactly as in the original study.

**New method:** for each group, retain its largest absolute adaptation deltas at
the common 10% or 30% rate. Floor the group quotas, then assign the remaining
positions by largest fractional remainder (canonical group order breaks ties).
This gives exactly floor(f*N) selected unique positions. Zero deltas count toward
the selected budget. No rescaling, gradients or performance-based allocation.

**Primary comparison:** balanced minus original relative-norm layer allocation
at 30% on a new confirmation sample, with a paired 95% document-bootstrap NLL
interval. A wholly negative Swedish interval supports this narrow comparison.
English changes are reported alongside it; Swedish improvement alone does not
establish an acceptable trade-off. No numerical English tolerance is invented.

The 10% comparison is secondary. Global magnitude and all three fixed random
seeds (17/29/43) are controls. Base and full adaptation anchor gain retention.
All methods are evaluated on the same new documents. No best seed is selected.
Intervals use 2,000 draws, seed 2026, and are pointwise. The frozen original
config fixes checkpoints, tokenizer, chunk boundaries, precision and batching.

**Two clearly separate evaluations:**

- Diagnostic: run only the two new balanced patches on the previously observed
  150-article-per-language corpus and reuse the saved original controls. This
  corpus helped motivate the method, so these are exploratory observations.
- Confirmation: collect 50 new Wikipedia articles per language under the same
  cleaning rules, rejecting original page IDs, Wikidata topics and text hashes.
  Freeze them before any follow-up model scoring. Run balanced, original layer,
  magnitude and three-seed random at both budgets, plus base and full adaptation
  (14 conditions). Fifty documents is an explicit CPU budget, not a subset chosen
  after inspecting performance. No method or parameter is tuned on either result.

Page/topic/hash disjointness does not establish freedom from similar text, mirrored
material, model pretraining overlap, or domain dependence. This remains a Wikipedia
comparison. It cannot by itself explain mechanisms or confirm general Swedish ability.

Original quantitative artifacts and the main research note remain unchanged. The
follow-up writes its own tables, figures and Markdown/PDF report under results/follow_up/
and reports/follow_up.*. Negative results will be reported in full.
