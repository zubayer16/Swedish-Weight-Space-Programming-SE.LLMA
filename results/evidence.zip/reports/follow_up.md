# Does Balanced Layer Allocation Preserve Swedish Adaptation?

Prespecified follow-up to the original SE.LLMA weight-space investigation.

## 1. What question does this follow-up test?

The original layer-aware method allocated retention using relative update norms and
lost to random selection on the observed Wikipedia corpus. I wanted to test whether
that allocation rule was discarding useful updates from less highly scored layers.
The new method therefore keeps the largest absolute deltas within every transformer
block at the same nominal rate. Embeddings and final normalization remain separate
groups. This is a single fixed change; no results were used to adjust its allocation.

The primary comparison is balanced versus original layer-aware selection at 30%.
The 10% condition is secondary. Global magnitude and random seeds 17/29/43 are controls.
This follow-up does not replace the original negative findings.

## 2. How was the comparison kept fair?

Each group receives floor(fraction times group size) positions, then the remaining
positions are assigned by largest fractional remainder, with canonical-order ties.
The exact global budget is still floor(fraction times total unique parameters).
Within each group, magnitude ties use parameter and row-major position order.
Zero deltas count as selected positions. There is no rescaling or behavioral tuning.

The checkpoint revisions, float32 arithmetic, base restoration, tokenizer, causal
targets, 128-token chunks, independent document contexts and batching remain those
of the completed main study. The original patch functions and measurements remain
unchanged. Unit tests, real-checkpoint zero/full reconstruction and batched/scalar
agreement were checked before follow-up scoring. Group allocations are exported.
The Swedish card names an Instruct parent in metadata, whereas its prose and paper
describe original-model continued pretraining. Until resolved, the delta cannot be
attributed exclusively to Swedish training; structural checks do not prove ancestry.

The plan was saved before collecting confirmation texts (reports/follow_up_plan.md).
Two balanced patches were first scored on the already observed 150-document-per-language
Wikipedia set. Saved original controls were reused on those identical texts. This
diagnostic is exploratory because those results motivated the new method.

A new, frozen set of 50 Wikipedia excerpts per language provides confirmation. Original
page IDs, Wikidata topics and content hashes were excluded during collection. The same
prose cleaning, provenance and CC BY-SA attribution rules apply. All 14 conditions
use every new document: 17,748 Swedish and
10,155 English target tokens. Fifty documents per language
was chosen in advance to bound CPU cost. Total collection and execution took
25.8 minutes on cpu.

## 3. What happened on the new confirmation sample?

NLL is token-weighted, in nats/token; lower is better. Random rows average the fixed
three seeds. Swedish gain retention is only defined when the full-adaptation gain
has a strictly positive paired interval. Negative retention means worse than base.

| Method | Retained | Swedish NLL | English NLL | SV gain | EN change |
|---|---:|---:|---:|---:|---:|
| base | 0% | 4.210 | 2.962 | 0.0% | +0.000 |
| adapted | 100% | 2.187 | 3.763 | 100.0% | +0.801 |
| random | 10% | 4.264 | 3.218 | -2.7% | +0.256 |
| magnitude | 10% | 4.545 | 3.797 | -16.6% | +0.835 |
| layer | 10% | 4.502 | 3.661 | -14.5% | +0.699 |
| balanced | 10% | 4.510 | 3.811 | -14.9% | +0.849 |
| random | 30% | 4.248 | 3.622 | -1.9% | +0.660 |
| magnitude | 30% | 3.998 | 4.356 | 10.5% | +1.394 |
| layer | 30% | 4.371 | 4.339 | -8.0% | +1.377 |
| balanced | 30% | 4.049 | 4.412 | 7.9% | +1.450 |

The primary Swedish balanced-minus-layer difference at 30% is -0.322,
with a paired 95% interval [-0.380, -0.268]. The primary comparison supports balanced allocation on this confirmation sample.
English changes must be considered separately; no acceptable-regression threshold
was invented after observing the results.

| Language | Balanced minus control | Retained | NLL difference | 95% interval |
|---|---|---:|---:|---:|
| sv | layer | 10% | +0.009 | [-0.008, +0.025] |
| sv | magnitude | 10% | -0.035 | [-0.053, -0.017] |
| sv | random | 10% | +0.246 | [+0.218, +0.276] |
| sv | layer | 30% | -0.322 | [-0.380, -0.268] |
| sv | magnitude | 30% | +0.052 | [-0.010, +0.106] |
| sv | random | 30% | -0.199 | [-0.259, -0.136] |
| en | layer | 10% | +0.150 | [+0.131, +0.169] |
| en | magnitude | 10% | +0.014 | [-0.005, +0.032] |
| en | random | 10% | +0.593 | [+0.558, +0.627] |
| en | layer | 30% | +0.073 | [-0.016, +0.150] |
| en | magnitude | 30% | +0.056 | [-0.051, +0.140] |
| en | random | 30% | +0.791 | [+0.737, +0.851] |

Intervals resample whole paired documents 2,000 times, seed 2026. For random controls,
fixed-seed mean document losses are resampled; seed SD is reported separately.
Intervals are pointwise, with no multiple-comparison correction. Negative differences
favor balanced selection. Only the 30% Swedish comparison was designated primary.

## 4. What happened on the previously observed sample?

These are diagnostic findings, separate from the new confirmation scores. The original
controls are reused without rerunning or modifying their recorded observations.

| Method | Retained | Swedish NLL | English NLL | SV gain | EN change |
|---|---:|---:|---:|---:|---:|
| base | 0% | 4.146 | 2.873 | 0.0% | +0.000 |
| adapted | 100% | 2.132 | 3.712 | 100.0% | +0.838 |
| random | 10% | 4.197 | 3.122 | -2.5% | +0.248 |
| magnitude | 10% | 4.455 | 3.742 | -15.4% | +0.869 |
| layer | 10% | 4.427 | 3.588 | -13.9% | +0.714 |
| balanced | 10% | 4.430 | 3.747 | -14.1% | +0.873 |
| random | 30% | 4.171 | 3.544 | -1.2% | +0.670 |
| magnitude | 30% | 3.966 | 4.313 | 8.9% | +1.440 |
| layer | 30% | 4.332 | 4.289 | -9.2% | +1.416 |
| balanced | 30% | 3.985 | 4.369 | 8.0% | +1.496 |

## 5. What can be concluded?

This experiment tests an allocation rule, rather than showing that complete layers
or Swedish mechanisms have been understood. The 30% Swedish advantage indicates that
the earlier relative-norm allocation was unhelpful on this confirmation sample. It does not
prove that coordination is the explanation, that sparsity is preferable to a weaker
dense adaptation, or that this method is generally best.

The confirmation articles are disjoint by recorded pages, topics and hashes, but
similar passages and pretraining contamination remain possible. The method was motivated
by a Wikipedia result and confirmed on Wikipedia, so domain generalization is still
untested. One small checkpoint pair, short excerpts and 50 documents per language
limit precision. Both negative findings and English regressions are retained.

I would next compare against scaled dense adaptation and norm-matched controls on
separate development data, then test a fixed choice on another domain. Neither the
confirmation set nor this diagnostic should become an undisclosed tuning set.

## Research references

The original study is reports/research_note.md. Exact design, revisions and source
fingerprints are in results/follow_up/design.json. Corpus provenance is in
data/follow_up/dataset_manifest.json (SHA-256 9af5be798f97377e51f868a56fcca4a59f91cac0c974e836bb3372f9c934cc70).
Document losses, token counts, all comparisons and figures are under results/follow_up/.

Weight-Space Programming: https://rikiyat.github.io/blog/weight-space-programming/

Wikimedia text license: https://creativecommons.org/licenses/by-sa/4.0/
