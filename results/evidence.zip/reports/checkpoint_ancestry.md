# Checkpoint ancestry investigation

19 November 2026. This extends the assignment audit by inspecting released training
code and the target checkpoint's own training arguments. No experiments, checkpoints
or scores were changed. No researcher was contacted and nothing was committed or pushed.

**Conclusion: exact initialization remains unverified.** The inspected releases do
not contain a CPT initialization call/configuration linked to the specific Swedish
checkpoint. Neither replacing the base with Instruct nor dismissing the Instruct
metadata as a typo is justified by the evidence available here.

## Evidence inspected

| Source | Finding | What it establishes |
|---|---|---|
| Pinned Swedish model-card YAML | Declares `HuggingFaceTB/SmolLM2-135M-Instruct` as `base_model` | Explicit parent metadata, conflicting with the project's non-Instruct base; not an execution log. |
| Card prose and associated paper, section 4.1 | Describe original SmolLM2 135M continued pretraining on Swedish | Supports the project's intended design, but does not give the initialization revision or resolve the YAML conflict. |
| Original paper's GitHub training directory | Contains only `train/ift.py` | Does not release the target CPT training/initialization code at the inspected commit. |
| `train/ift.py`, lines 6–7 | Loads `jekunz/smollm-135m-fineweb-swedish-from-scratch` using `AutoModelForCausalLM.from_pretrained` | This is instruction tuning of a different from-scratch checkpoint, not initialization of the target CPT model. |
| Same script, lines 11 and 15 | Names a from-scratch Smol-Smoltalk output and loads Swedish Smol-Smoltalk | Confirms that this configuration belongs to the instruction-tuning stage. Its hyperparameters cannot be substituted for the target CPT run. |
| Original repository's `train/` history | One returned commit: `d2869ea66d45aad3e9272723e18e7ed852fde81a`, labelled “ift code” | No earlier CPT initialization file was identified through that directory history. |
| Target checkpoint's `training_args.bin` | Learning rate 0.0005, one epoch, `resume_from_checkpoint=None`, `hub_model_id=None`; no initialization model/revision recorded | Optimization/output settings agree with CPT documentation but do not identify the loaded parent. `resume_from_checkpoint=None` does not imply random initialization or prove a particular parent. |
| Target checkpoint's file listing and refs | Main branch only, no tags; weights/config/tokenizer/card/training arguments | No tagged step-zero checkpoint or separate model-initialization configuration was exposed in these refs. |
| Related `family-matters` release | `scripts/common.sh` selects SmolLM2-Instruct; `train/train.py` initializes full models from `args.init or args.base_model` | Shows explicit Instruct use in another study. An override is possible, and no link to this target checkpoint/run was found. This is supporting context, not proof of this checkpoint's ancestry. |
| Related `dialects-translationese` release | Constructs GPT-2 from a configuration | Not the target SmolLM2 initialization. |
| Related `idiomaticity-vocab` tree | No target CPT initialization/configuration identified | No additional resolution from the inspected tree. |

The binary training arguments were examined with `zipfile` and
`pickletools.genops`; they were **not unpickled or executed**. No remote training
code was executed. Small public source/configuration files were read, not model weights.

## Immutable source references

- [Original released instruction-tuning script](https://github.com/jekunz/idiomatic-language/blob/a84eaaff73a4f887e2bc95a0d8d66ef5bc36d808/train/ift.py#L6),
  repository commit `a84eaaff73a4f887e2bc95a0d8d66ef5bc36d808`.
- [Pinned model card](https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish/blob/3a80f1642cffaf656958647e213e49436415134d/README.md)
  and [released training arguments](https://huggingface.co/jekunz/smollm-135m-cpt-fineweb-swedish/blob/3a80f1642cffaf656958647e213e49436415134d/training_args.bin).
- [Associated paper, training setup](https://arxiv.org/html/2602.03484v1#S4.SS1).
- [Related Instruct selection](https://github.com/jekunz/family-matters/blob/d71c420e63a40afb7c3299c7eaede850cfb6f0d1/scripts/common.sh#L8)
  and [initialization/override code](https://github.com/jekunz/family-matters/blob/d71c420e63a40afb7c3299c7eaede850cfb6f0d1/train/train.py#L39).
- [Different-study GPT-2 initialization](https://github.com/jekunz/dialects-translationese/blob/c07acc073eff8c63a26f859a9c6f0a2ab6bea456/scripts/train_single_model.py).

Machine-readable evidence, inspected file lists, source hashes, selected static
training-argument fields and repository commits are saved in
`results/evaluator_audit/checkpoint_ancestry.json`. This records the scope of the
search, not a claim that the initialization code cannot exist elsewhere.

## Implication and exact information still needed

The reported likelihoods and sparse interventions remain measurements of the two
pinned checkpoints. Structural compatibility and reconstruction do not establish
that their difference consists solely of Swedish continued-pretraining updates.
The existing ancestry caveat in all current research reports remains necessary.

To resolve it, obtain a training configuration/log tied to the target checkpoint
that specifies:

1. The exact `from_pretrained` model identifier and revision before CPT.
2. Any resumed or intermediate checkpoint loaded before training.
3. Whether the card's Instruct parent is intentional or an erroneous metadata field.

A precise question for the researcher would be: “For
`jekunz/smollm-135m-cpt-fineweb-swedish` at revision
`3a80f1642cffaf656958647e213e49436415134d`, was CPT initialized from
`HuggingFaceTB/SmolLM2-135M` or `HuggingFaceTB/SmolLM2-135M-Instruct`, at which revision,
and is there a launch config/log establishing that? The model-card metadata names
Instruct while the paper describes original-model CPT.” This question has not been sent.
