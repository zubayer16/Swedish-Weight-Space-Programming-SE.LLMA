# Frozen Wikipedia evaluation and legacy development data

`eval_sv.jsonl` and `eval_en.jsonl` contain 150 independently collected Wikipedia
article excerpts each. They are community-written source text, with no translation
or AI-generated replacement text. Human-only authorship cannot be guaranteed for
all Wikipedia contributions. Marked automated articles are filtered out.

## Collection and exact reproduction

```sh
python -m src.datasets
python -m src.datasets --verify-only
```

Once `dataset_manifest.json` exists, the first command verifies the frozen files
without network access, text changes or resampling. Use the committed JSONL files
to reproduce evaluation exactly. To make a new sample, explicitly use a new
`--output` directory; do not overwrite this evaluation set after seeing results.
The public random API is not seedable and lists a fixed sequence from a random
starting point. It does not promise IID random sampling. Reproducibility is provided
by frozen bytes, ordered article IDs, revision IDs, and SHA-256 hashes.
`.gitattributes` disables line-ending conversion for these files so their byte
hashes remain valid after checkout on Windows, Linux or macOS.

Both languages use these fixed rules (also embedded in the manifest):

1. Wikimedia Action API random generator, namespace 0, nonredirects, minimum
   5,000 source bytes, batches of 20. Process returned generator indices, falling
   back to page ID order when indices are absent. The first 150 qualifying pages
   are accepted without inspecting model scores.
2. Exclude disambiguation properties, list-title prefixes, marked bot/AI-generated
   articles, obvious copyright-problem templates, duplicate page IDs, identical
   cleaned-text hashes, and repeated Wikidata IDs (also across languages).
3. Obtain the revision ID and source timestamp, then parse that exact revision.
   Keep HTML `p` paragraphs in article order, excluding tables, lists, images,
   notices, citations and reference/bibliography/external-link sections. A paragraph
   must contain at least 20 whitespace words, sentence punctuation, and at least
   60% alphabetic nonspace characters. Normalize Unicode NFC and whitespace.
4. Require at least 100 cleaned prose words. Retain a sentence-ended prefix of
   100–200 words, preferring the first boundary at or after 120 words; if none,
   use the last boundary between 100 and 119 words. This is an explicit article
   excerpt, not the entire article. Word and original cleaned-prose counts are saved.

An initial lead-only pilot excluded too many substantial Swedish articles with
short introductions. Before any expanded model evaluation, the rule was changed
for both languages to include body prose. Cached candidates were reprocessed in
the same sequence. No behavior measurements influenced this adjustment.

Requests run serially, at least one second apart, with `maxlag=5`, an identifiable
project URL in the User-Agent, six-attempt retry/backoff and `Retry-After` handling.
Responses are cached locally. Failed requests are recorded; exhausted retries or
an incomplete sample produce an explicit failure and no completed manifest.
An interrupted collector resumes its saved queue. Evaluation refuses incomplete
datasets, unexpected counts or hash changes. Parsing an old revision can still
depend on changing templates; the frozen cleaned bytes are the reproducibility
authority, not a promise of byte-identical future API rendering.

`collection_audit_sv.json` and `collection_audit_en.json` record accepted and rejected
candidate IDs/titles and reasons. The manifest records file hashes, ordered document
IDs, rules, script hash, counts, timestamps and API errors.

## Attribution and licensing

Each document includes language, text, article title/ID, revision ID and timestamp,
retrieval time, article/revision/history URLs, content SHA-256, license name/URL,
credit to Wikipedia contributors, preserved imported-text notices when detected,
and a description of extraction changes. See [LICENSE.md](LICENSE.md).
Distribute the JSONL with this attribution metadata and license notice.

## Held-out status and legacy examples

The frozen Wikipedia documents are held out from this project's mask design and
hyperparameter choices. They are not proven absent from model pretraining:
Wikipedia and its mirrors may appear in base training and FineWeb-2, and much of
a recent revision may be old text. No contamination removal was performed.

`sample_sv.jsonl` and `sample_en.jsonl` remain byte-for-byte unchanged: each contains
3 original development and 8 original test texts authored by Codex. All 11 per
language are now used only as **legacy development** examples. Their old `split`
fields preserve the historical record; the updated loader remaps them to dev.
Original main measurements remain under `results/full/`; redundant smoke outputs were removed.

Full mode scores every frozen Wikipedia document with the unchanged tokenizer and
causal scorer: no extra specials, no padding, no document concatenation, 128-token
chunks with one boundary token shared, all targets except each document's first.
Equal-length chunks may share an inference batch but never share context; no padding
is introduced. The original scalar implementation is retained as the numerical reference.
There is no further truncation. Quick mode explicitly uses the first 2 documents
per language and 2 legacy development documents; it is only a smoke run.

This filtered opening-prose corpus is not representative of all language domains,
nor a benchmark for reasoning, idioms, or Swedish cultural knowledge. The optional
Literature Bank check is deferred and has no reported measurements.

The balanced follow-up corpus is frozen separately under `follow_up/`. The scaled
dense experiment collects another corpus under `dense_follow_up/`, excluding both
earlier corpora by language/page ID, Wikidata topic and content hash. Each has its
own manifest and per-document attribution; the licensing and cleaning rules above
and in `LICENSE.md` apply to both. Dense alpha is selected on the legacy examples
before the dense confirmation corpus is collected. None of the Wikipedia corpora
is used to select alpha.
